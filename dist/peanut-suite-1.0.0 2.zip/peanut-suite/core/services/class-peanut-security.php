<?php
/**
 * Security Service
 *
 * Input sanitization, rate limiting, and security utilities.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Peanut_Security {

    /**
     * Sanitize field by type
     */
    public static function sanitize_field(string $key, mixed $value): string {
        if (!is_string($value) && !is_numeric($value)) {
            return '';
        }

        $value = (string) $value;
        $key_lower = strtolower($key);

        // Email
        if (str_contains($key_lower, 'email')) {
            return sanitize_email($value);
        }

        // Phone
        if (str_contains($key_lower, 'phone') || str_contains($key_lower, 'mobile')) {
            return preg_replace('/[^\d\-\(\)\+\s]/', '', $value);
        }

        // URL
        if (str_contains($key_lower, 'url') || str_contains($key_lower, 'website')) {
            return esc_url_raw($value);
        }

        // UTM parameters
        if (str_starts_with($key_lower, 'utm_')) {
            return preg_replace('/[^A-Za-z0-9\-_\+\%]/', '', $value);
        }

        return sanitize_text_field($value);
    }

    /**
     * Sanitize array of fields
     */
    public static function sanitize_fields(array $data): array {
        $sanitized = [];
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $sanitized[$key] = self::sanitize_fields($value);
            } else {
                $sanitized[$key] = self::sanitize_field($key, $value);
            }
        }
        return $sanitized;
    }

    /**
     * Check rate limit
     */
    public static function check_rate_limit(string $action, int $max = 60, int $window = 60): bool {
        $ip = self::get_client_ip();
        $key = 'peanut_rate_' . md5($action . '_' . $ip);

        $data = get_transient($key);

        if ($data === false) {
            set_transient($key, ['count' => 1, 'started' => time()], $window);
            return true;
        }

        if (time() - $data['started'] > $window) {
            set_transient($key, ['count' => 1, 'started' => time()], $window);
            return true;
        }

        $data['count']++;
        set_transient($key, $data, $window);

        return $data['count'] <= $max;
    }

    /**
     * Get client IP (Cloudflare-aware)
     */
    public static function get_client_ip(): string {
        $ip_keys = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];

        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                if (str_contains($ip, ',')) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }

    /**
     * Validate URL is safe
     */
    public static function is_safe_url(string $url): bool {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $parsed = parse_url($url);
        if (!$parsed || empty($parsed['host'])) {
            return false;
        }

        if (!in_array($parsed['scheme'] ?? '', ['http', 'https'], true)) {
            return false;
        }

        // Block localhost
        if (in_array($parsed['host'], ['localhost', '127.0.0.1', '0.0.0.0'], true)) {
            return false;
        }

        return true;
    }
}
