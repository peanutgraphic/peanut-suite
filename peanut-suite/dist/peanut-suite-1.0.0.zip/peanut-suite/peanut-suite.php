<?php
/**
 * Plugin Name: Peanut Suite
 * Plugin URI: https://peanutgraphic.com/peanut-suite
 * Description: Complete marketing toolkit - UTM campaigns, link management, lead tracking, and analytics in one unified dashboard.
 * Version: 1.0.0
 * Author: Peanut Graphic
 * Author URI: https://peanutgraphic.com
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: peanut-suite
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Prevent loading twice
if (defined('PEANUT_VERSION')) {
    return;
}

/**
 * Plugin constants
 */
define('PEANUT_VERSION', '1.0.0');
define('PEANUT_SUITE_VERSION', '1.0.0'); // Alias for updater
define('PEANUT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PEANUT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PEANUT_PLUGIN_BASENAME', plugin_basename(__FILE__));

// API namespace
define('PEANUT_API_NAMESPACE', 'peanut/v1');

// Table prefix
define('PEANUT_TABLE_PREFIX', 'peanut_');

/**
 * Autoloader for plugin classes
 */
spl_autoload_register(function ($class) {
    // Check for Peanut_ prefix (core classes)
    if (strpos($class, 'Peanut_') === 0) {
        $class_name = str_replace('Peanut_', '', $class);
        $class_name = strtolower(str_replace('_', '-', $class_name));

        $directories = [
            PEANUT_PLUGIN_DIR . 'core/',
            PEANUT_PLUGIN_DIR . 'core/database/',
            PEANUT_PLUGIN_DIR . 'core/api/',
            PEANUT_PLUGIN_DIR . 'core/services/',
            PEANUT_PLUGIN_DIR . 'core/admin/',
        ];

        foreach ($directories as $directory) {
            $file = $directory . 'class-peanut-' . $class_name . '.php';
            if (file_exists($file)) {
                require_once $file;
                return;
            }
        }
    }

    // Check for module classes (Module_Name_Class format)
    if (preg_match('/^(UTM|Links|Contacts|Popups|Dashboard)_(.+)$/', $class, $matches)) {
        $module = strtolower($matches[1]);
        $class_name = strtolower(str_replace('_', '-', $matches[2]));

        $directories = [
            PEANUT_PLUGIN_DIR . "modules/{$module}/",
            PEANUT_PLUGIN_DIR . "modules/{$module}/api/",
        ];

        foreach ($directories as $directory) {
            $file = $directory . 'class-' . $module . '-' . $class_name . '.php';
            if (file_exists($file)) {
                require_once $file;
                return;
            }
        }
    }
});

/**
 * Plugin activation
 */
function peanut_activate() {
    require_once PEANUT_PLUGIN_DIR . 'core/class-peanut-activator.php';
    Peanut_Activator::activate();
}
register_activation_hook(__FILE__, 'peanut_activate');

/**
 * Plugin deactivation
 */
function peanut_deactivate() {
    require_once PEANUT_PLUGIN_DIR . 'core/class-peanut-deactivator.php';
    Peanut_Deactivator::deactivate();
}
register_deactivation_hook(__FILE__, 'peanut_deactivate');

/**
 * Initialize the plugin
 */
function peanut_init() {
    // Load text domain
    load_plugin_textdomain(
        'peanut-suite',
        false,
        dirname(PEANUT_PLUGIN_BASENAME) . '/languages/'
    );

    // Initialize core
    require_once PEANUT_PLUGIN_DIR . 'core/class-peanut-core.php';
    $core = new Peanut_Core();
    $core->run();
}
add_action('plugins_loaded', 'peanut_init');

/**
 * Helper: Get active modules
 */
function peanut_get_active_modules(): array {
    return get_option('peanut_active_modules', [
        'utm' => true,
        'links' => true,
        'contacts' => true,
        'dashboard' => true,
        'popups' => false, // Pro feature
    ]);
}

/**
 * Helper: Check if module is active
 */
function peanut_is_module_active(string $module): bool {
    $modules = peanut_get_active_modules();
    return !empty($modules[$module]);
}

/**
 * Helper: Get license data
 */
function peanut_get_license(): array {
    static $license = null;
    if ($license === null) {
        require_once PEANUT_PLUGIN_DIR . 'core/services/class-peanut-license.php';
        $service = new Peanut_License();
        $license = $service->get_license_data();
    }
    return $license;
}

/**
 * Helper: Check if pro features available
 */
function peanut_is_pro(): bool {
    $license = peanut_get_license();
    return in_array($license['tier'] ?? '', ['pro', 'agency'], true);
}

/**
 * Helper: Check if agency tier
 */
function peanut_is_agency(): bool {
    $license = peanut_get_license();
    return ($license['tier'] ?? '') === 'agency';
}

/**
 * Initialize self-hosted updater
 */
function peanut_init_updater(): void {
    require_once PEANUT_PLUGIN_DIR . 'core/services/class-peanut-updater.php';
    new Peanut_Updater();
}
add_action('admin_init', 'peanut_init_updater');

/**
 * Fire action for add-ons to hook into
 */
do_action('peanut_loaded');
