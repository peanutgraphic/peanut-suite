/**
 * Peanut Popups Frontend Engine
 *
 * Handles popup display triggers, animations, and form submissions.
 */

(function() {
    'use strict';

    // Exit if no popups data
    if (typeof peanutPopups === 'undefined' || !peanutPopups.popups) {
        return;
    }

    const { ajaxUrl, nonce, popups } = peanutPopups;

    // Track shown popups to prevent duplicates
    const shownPopups = new Set();

    // Page view counter for page_views trigger
    let pageViews = parseInt(localStorage.getItem('peanut_page_views') || '0', 10) + 1;
    localStorage.setItem('peanut_page_views', pageViews.toString());

    /**
     * Initialize popup triggers
     */
    function init() {
        popups.forEach(popup => {
            setupTrigger(popup);
        });

        // Setup close handlers
        setupCloseHandlers();

        // Setup form handlers
        setupFormHandlers();
    }

    /**
     * Setup trigger for a popup
     */
    function setupTrigger(popup) {
        const trigger = popup.triggers;
        if (!trigger || !trigger.type) return;

        switch (trigger.type) {
            case 'time_delay':
                setTimeout(() => showPopup(popup.id), trigger.delay || 5000);
                break;

            case 'scroll_percent':
                setupScrollPercentTrigger(popup.id, trigger.percent || 50);
                break;

            case 'scroll_element':
                setupScrollElementTrigger(popup.id, trigger.selector, trigger.offset || 0);
                break;

            case 'exit_intent':
                setupExitIntentTrigger(popup.id, trigger.sensitivity || 20, trigger.delay || 0);
                break;

            case 'click':
                setupClickTrigger(popup.id, trigger.selector);
                break;

            case 'page_views':
                if (pageViews >= (trigger.count || 3)) {
                    setTimeout(() => showPopup(popup.id), 1000);
                }
                break;

            case 'inactivity':
                setupInactivityTrigger(popup.id, trigger.timeout || 30000);
                break;
        }
    }

    /**
     * Setup scroll percentage trigger
     */
    function setupScrollPercentTrigger(popupId, percent) {
        let triggered = false;

        function checkScroll() {
            if (triggered) return;

            const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
            const scrollPercent = (window.scrollY / scrollHeight) * 100;

            if (scrollPercent >= percent) {
                triggered = true;
                showPopup(popupId);
                window.removeEventListener('scroll', checkScroll);
            }
        }

        window.addEventListener('scroll', checkScroll, { passive: true });
    }

    /**
     * Setup scroll to element trigger
     */
    function setupScrollElementTrigger(popupId, selector, offset) {
        if (!selector) return;

        let triggered = false;
        const element = document.querySelector(selector);

        if (!element) return;

        function checkScroll() {
            if (triggered) return;

            const rect = element.getBoundingClientRect();
            const triggerPoint = window.innerHeight - offset;

            if (rect.top <= triggerPoint) {
                triggered = true;
                showPopup(popupId);
                window.removeEventListener('scroll', checkScroll);
            }
        }

        window.addEventListener('scroll', checkScroll, { passive: true });
    }

    /**
     * Setup exit intent trigger
     */
    function setupExitIntentTrigger(popupId, sensitivity, delay) {
        let triggered = false;
        let delayTimer = null;

        function handleMouseLeave(e) {
            if (triggered) return;

            // Only trigger when mouse leaves through top of page
            if (e.clientY <= sensitivity) {
                if (delay > 0) {
                    delayTimer = setTimeout(() => {
                        triggered = true;
                        showPopup(popupId);
                    }, delay);
                } else {
                    triggered = true;
                    showPopup(popupId);
                }
            }
        }

        function handleMouseEnter() {
            if (delayTimer) {
                clearTimeout(delayTimer);
                delayTimer = null;
            }
        }

        document.addEventListener('mouseleave', handleMouseLeave);
        document.addEventListener('mouseenter', handleMouseEnter);

        // Mobile: trigger on back button or page hide
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden' && !triggered) {
                triggered = true;
                showPopup(popupId);
            }
        });
    }

    /**
     * Setup click trigger
     */
    function setupClickTrigger(popupId, selector) {
        if (!selector) return;

        document.addEventListener('click', (e) => {
            if (e.target.matches(selector) || e.target.closest(selector)) {
                e.preventDefault();
                showPopup(popupId);
            }
        });
    }

    /**
     * Setup inactivity trigger
     */
    function setupInactivityTrigger(popupId, timeout) {
        let timer;

        function resetTimer() {
            clearTimeout(timer);
            timer = setTimeout(() => showPopup(popupId), timeout);
        }

        ['mousemove', 'keydown', 'scroll', 'touchstart'].forEach(event => {
            document.addEventListener(event, resetTimer, { passive: true });
        });

        resetTimer();
    }

    /**
     * Show a popup
     */
    function showPopup(popupId) {
        if (shownPopups.has(popupId)) return;

        const popup = document.getElementById(`peanut-popup-${popupId}`);
        if (!popup) return;

        shownPopups.add(popupId);

        // Show popup with animation
        popup.style.display = '';
        requestAnimationFrame(() => {
            popup.classList.add('peanut-popup-visible');
        });

        // Track view
        trackInteraction(popupId, 'view');

        // Prevent body scroll for modals and fullscreen
        if (popup.classList.contains('peanut-popup-modal') ||
            popup.classList.contains('peanut-popup-fullscreen')) {
            document.body.style.overflow = 'hidden';
        }
    }

    /**
     * Hide a popup
     */
    function hidePopup(popupId, reason = 'dismiss') {
        const popup = document.getElementById(`peanut-popup-${popupId}`);
        if (!popup) return;

        popup.classList.remove('peanut-popup-visible');

        // Wait for animation
        setTimeout(() => {
            popup.style.display = 'none';
            document.body.style.overflow = '';
        }, 300);

        // Track dismissal
        if (reason === 'dismiss') {
            trackInteraction(popupId, 'dismiss');
        }
    }

    /**
     * Setup close handlers
     */
    function setupCloseHandlers() {
        // Close button
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('peanut-popup-close') ||
                e.target.closest('.peanut-popup-close')) {
                const popup = e.target.closest('.peanut-popup');
                if (popup) {
                    const popupId = popup.dataset.popupId;
                    hidePopup(popupId);
                }
            }
        });

        // Overlay click
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('peanut-popup-overlay')) {
                const popup = e.target.closest('.peanut-popup');
                const settings = getPopupSettings(popup.dataset.popupId);

                if (settings.close_on_overlay !== false) {
                    hidePopup(popup.dataset.popupId);
                }
            }
        });

        // ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const visiblePopup = document.querySelector('.peanut-popup-visible');
                if (visiblePopup) {
                    const settings = getPopupSettings(visiblePopup.dataset.popupId);

                    if (settings.close_on_esc !== false) {
                        hidePopup(visiblePopup.dataset.popupId);
                    }
                }
            }
        });
    }

    /**
     * Setup form handlers
     */
    function setupFormHandlers() {
        document.addEventListener('submit', (e) => {
            if (e.target.classList.contains('peanut-popup-form')) {
                e.preventDefault();
                handleFormSubmit(e.target);
            }
        });
    }

    /**
     * Handle form submission
     */
    async function handleFormSubmit(form) {
        const popupId = form.dataset.popupId;
        const popup = document.getElementById(`peanut-popup-${popupId}`);
        const button = form.querySelector('.peanut-popup-button');
        const successDiv = popup.querySelector('.peanut-popup-success');

        // Collect form data
        const formData = {};
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            if (input.name) {
                if (input.type === 'checkbox') {
                    formData[input.name] = input.checked;
                } else {
                    formData[input.name] = input.value;
                }
            }
        });

        // Disable button
        button.disabled = true;
        button.textContent = 'Sending...';

        try {
            const response = await fetch(ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'peanut_popup_convert',
                    nonce: nonce,
                    popup_id: popupId,
                    'form_data': JSON.stringify(formData),
                }),
            });

            const result = await response.json();

            if (result.success) {
                // Show success message
                form.style.display = 'none';
                if (successDiv) {
                    successDiv.style.display = '';
                }

                // Close after delay
                setTimeout(() => {
                    hidePopup(popupId, 'convert');
                }, 3000);
            } else {
                throw new Error(result.data || 'Submission failed');
            }
        } catch (error) {
            console.error('Popup form error:', error);
            button.disabled = false;
            button.textContent = 'Try Again';
        }
    }

    /**
     * Track popup interaction
     */
    function trackInteraction(popupId, action) {
        fetch(ajaxUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: `peanut_popup_${action}`,
                nonce: nonce,
                popup_id: popupId,
            }),
        }).catch(console.error);
    }

    /**
     * Get popup settings
     */
    function getPopupSettings(popupId) {
        const popup = popups.find(p => p.id == popupId);
        return popup?.settings || {};
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
