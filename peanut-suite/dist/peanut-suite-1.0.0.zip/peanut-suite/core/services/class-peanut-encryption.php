<?php
/**
 * Encryption Service
 *
 * AES-256-CBC encryption for sensitive data (tokens, API keys, etc.)
 */

if (!defined('ABSPATH')) {
    exit;
}

class Peanut_Encryption {

    private const METHOD = 'AES-256-CBC';
    private const IV_LENGTH = 16;

    private string $key;

    public function __construct(?string $key = null) {
        $this->key = $key ?? $this->derive_key();
    }

    private function derive_key(): string {
        if (defined('PEANUT_ENCRYPTION_KEY') && PEANUT_ENCRYPTION_KEY) {
            return hash('sha256', PEANUT_ENCRYPTION_KEY, true);
        }
        return hash('sha256', wp_salt('auth'), true);
    }

    public function encrypt(string $data): string {
        if (empty($data)) {
            return '';
        }

        $iv = openssl_random_pseudo_bytes(self::IV_LENGTH);
        if ($iv === false) {
            return '';
        }

        $encrypted = openssl_encrypt($data, self::METHOD, $this->key, OPENSSL_RAW_DATA, $iv);
        if ($encrypted === false) {
            return '';
        }

        return base64_encode($iv . $encrypted);
    }

    public function decrypt(string $data): string {
        if (empty($data)) {
            return '';
        }

        $decoded = base64_decode($data, true);
        if ($decoded === false || strlen($decoded) < self::IV_LENGTH) {
            return '';
        }

        $iv = substr($decoded, 0, self::IV_LENGTH);
        $ciphertext = substr($decoded, self::IV_LENGTH);

        $decrypted = openssl_decrypt($ciphertext, self::METHOD, $this->key, OPENSSL_RAW_DATA, $iv);
        return $decrypted !== false ? $decrypted : '';
    }

    public static function mask(string $data, int $visible_end = 4): string {
        $length = strlen($data);
        if ($length <= $visible_end) {
            return str_repeat('*', $length);
        }
        return str_repeat('*', $length - $visible_end) . substr($data, -$visible_end);
    }

    public static function generate_token(int $length = 32): string {
        return bin2hex(random_bytes($length));
    }
}
