<?php
/**
 * Peanut Suite Core
 *
 * Main orchestrator that initializes all components and modules.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Peanut_Core {

    /**
     * Registered modules
     */
    private array $modules = [];

    /**
     * Module manager
     */
    private ?Peanut_Module_Manager $module_manager = null;

    /**
     * Constructor
     */
    public function __construct() {
        $this->load_dependencies();
    }

    /**
     * Load required dependencies
     */
    private function load_dependencies(): void {
        // Core services
        require_once PEANUT_PLUGIN_DIR . 'core/services/class-peanut-encryption.php';
        require_once PEANUT_PLUGIN_DIR . 'core/services/class-peanut-security.php';
        require_once PEANUT_PLUGIN_DIR . 'core/services/class-peanut-license.php';

        // Database
        require_once PEANUT_PLUGIN_DIR . 'core/database/class-peanut-database.php';

        // API
        require_once PEANUT_PLUGIN_DIR . 'core/api/class-peanut-rest-controller.php';
        require_once PEANUT_PLUGIN_DIR . 'core/api/class-peanut-settings-controller.php';

        // Admin
        require_once PEANUT_PLUGIN_DIR . 'core/admin/class-peanut-admin.php';
        require_once PEANUT_PLUGIN_DIR . 'core/admin/class-peanut-module-manager.php';
    }

    /**
     * Run the plugin
     */
    public function run(): void {
        // Initialize module manager
        $this->module_manager = new Peanut_Module_Manager();

        // Register built-in modules
        $this->register_modules();

        // Initialize active modules
        $this->module_manager->init_modules();

        // Setup hooks
        $this->define_admin_hooks();
        $this->define_api_hooks();
        $this->define_cron_hooks();

        // Fire action for add-ons
        do_action('peanut_modules_loaded', $this->module_manager);
    }

    /**
     * Register built-in modules
     */
    private function register_modules(): void {
        // UTM Module
        $this->module_manager->register('utm', [
            'name' => __('UTM Campaigns', 'peanut-suite'),
            'description' => __('Create and manage UTM tracking codes for your marketing campaigns.', 'peanut-suite'),
            'icon' => 'chart-line',
            'file' => PEANUT_PLUGIN_DIR . 'modules/utm/class-utm-module.php',
            'class' => 'UTM_Module',
            'default' => true,
            'pro' => false,
        ]);

        // Links Module
        $this->module_manager->register('links', [
            'name' => __('Link Manager', 'peanut-suite'),
            'description' => __('Shorten URLs, generate QR codes, and track link clicks.', 'peanut-suite'),
            'icon' => 'link',
            'file' => PEANUT_PLUGIN_DIR . 'modules/links/class-links-module.php',
            'class' => 'Links_Module',
            'default' => true,
            'pro' => false,
        ]);

        // Contacts Module
        $this->module_manager->register('contacts', [
            'name' => __('Contacts', 'peanut-suite'),
            'description' => __('Manage leads and contacts from all your marketing channels.', 'peanut-suite'),
            'icon' => 'users',
            'file' => PEANUT_PLUGIN_DIR . 'modules/contacts/class-contacts-module.php',
            'class' => 'Contacts_Module',
            'default' => true,
            'pro' => false,
        ]);

        // Dashboard Module
        $this->module_manager->register('dashboard', [
            'name' => __('Dashboard', 'peanut-suite'),
            'description' => __('Unified analytics dashboard for all your marketing data.', 'peanut-suite'),
            'icon' => 'layout-dashboard',
            'file' => PEANUT_PLUGIN_DIR . 'modules/dashboard/class-dashboard-module.php',
            'class' => 'Dashboard_Module',
            'default' => true,
            'pro' => false,
        ]);

        // Popups Module (Pro)
        $this->module_manager->register('popups', [
            'name' => __('Popups', 'peanut-suite'),
            'description' => __('Create exit-intent popups, slide-ins, and modals to capture leads.', 'peanut-suite'),
            'icon' => 'message-square',
            'file' => PEANUT_PLUGIN_DIR . 'modules/popups/class-popups-module.php',
            'class' => 'Popups_Module',
            'default' => false,
            'pro' => true,
        ]);

        // Monitor Module (Agency)
        $this->module_manager->register('monitor', [
            'name' => __('Monitor', 'peanut-suite'),
            'description' => __('Manage multiple WordPress sites from one dashboard. View health, updates, and aggregated analytics.', 'peanut-suite'),
            'icon' => 'monitor',
            'file' => PEANUT_PLUGIN_DIR . 'modules/monitor/class-monitor-module.php',
            'class' => 'Monitor_Module',
            'default' => false,
            'pro' => true,
            'tier' => 'agency',
        ]);

        // Allow add-ons to register modules
        do_action('peanut_register_modules', $this->module_manager);
    }

    /**
     * Define admin hooks
     */
    private function define_admin_hooks(): void {
        $admin = new Peanut_Admin();

        add_action('admin_menu', [$admin, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$admin, 'enqueue_scripts']);
        add_action('admin_enqueue_scripts', [$admin, 'enqueue_styles']);
    }

    /**
     * Define REST API hooks
     */
    private function define_api_hooks(): void {
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }

    /**
     * Register REST API routes
     */
    public function register_rest_routes(): void {
        // Core settings endpoint
        $settings_controller = new Peanut_Settings_Controller();
        $settings_controller->register_routes();

        // Let modules register their routes
        do_action('peanut_register_routes');
    }

    /**
     * Define cron hooks
     */
    private function define_cron_hooks(): void {
        // Add custom cron intervals
        add_filter('cron_schedules', [$this, 'add_cron_intervals']);

        add_action('peanut_daily_maintenance', [$this, 'run_daily_maintenance']);

        // Schedule cron if not exists
        if (!wp_next_scheduled('peanut_daily_maintenance')) {
            wp_schedule_event(time(), 'daily', 'peanut_daily_maintenance');
        }
    }

    /**
     * Add custom cron intervals
     */
    public function add_cron_intervals(array $schedules): array {
        $schedules['peanut_five_minutes'] = [
            'interval' => 5 * MINUTE_IN_SECONDS,
            'display' => __('Every 5 Minutes', 'peanut-suite'),
        ];

        $schedules['peanut_fifteen_minutes'] = [
            'interval' => 15 * MINUTE_IN_SECONDS,
            'display' => __('Every 15 Minutes', 'peanut-suite'),
        ];

        return $schedules;
    }

    /**
     * Run daily maintenance tasks
     */
    public function run_daily_maintenance(): void {
        // License check
        $license = new Peanut_License();
        $license->validate_license(get_option('peanut_license_key', ''), true);

        // Cleanup expired data
        Peanut_Database::cleanup_expired_cache();

        // Let modules run maintenance
        do_action('peanut_daily_maintenance_tasks');
    }

    /**
     * Get module manager
     */
    public function get_module_manager(): Peanut_Module_Manager {
        return $this->module_manager;
    }
}
