<?php
/**
 * Plugin Activator
 */

if (!defined('ABSPATH')) {
    exit;
}

class Peanut_Activator {

    public static function activate(): void {
        // Check PHP version
        if (version_compare(PHP_VERSION, '8.0', '<')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                __('Peanut Suite requires PHP 8.0 or higher.', 'peanut-suite'),
                'Plugin Activation Error',
                ['back_link' => true]
            );
        }

        // Check WordPress version
        if (version_compare(get_bloginfo('version'), '6.0', '<')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                __('Peanut Suite requires WordPress 6.0 or higher.', 'peanut-suite'),
                'Plugin Activation Error',
                ['back_link' => true]
            );
        }

        // Load database classes
        require_once PEANUT_PLUGIN_DIR . 'core/database/class-peanut-database.php';

        // Create core tables
        Peanut_Database::create_tables();

        // Create module-specific tables
        self::create_module_tables();

        // Set default options
        self::set_defaults();

        // Schedule cron
        if (!wp_next_scheduled('peanut_daily_maintenance')) {
            wp_schedule_event(time(), 'daily', 'peanut_daily_maintenance');
        }

        // Flush rewrite rules for link redirects
        flush_rewrite_rules();

        // Set activation flag
        set_transient('peanut_activated', true, 30);
    }

    private static function set_defaults(): void {
        // Default active modules
        if (get_option('peanut_active_modules') === false) {
            update_option('peanut_active_modules', [
                'utm' => true,
                'links' => true,
                'contacts' => true,
                'dashboard' => true,
                'popups' => false,
                'monitor' => false,
            ]);
        }

        // Default settings
        if (get_option('peanut_settings') === false) {
            update_option('peanut_settings', [
                'link_prefix' => 'go',
                'track_clicks' => true,
                'anonymize_ip' => false,
            ]);
        }
    }

    /**
     * Create module-specific tables
     */
    private static function create_module_tables(): void {
        // Monitor module tables
        $monitor_db = PEANUT_PLUGIN_DIR . 'modules/monitor/class-monitor-database.php';
        if (file_exists($monitor_db)) {
            require_once $monitor_db;
            Monitor_Database::create_tables();
        }

        // Popups module tables
        $popups_db = PEANUT_PLUGIN_DIR . 'modules/popups/class-popups-database.php';
        if (file_exists($popups_db)) {
            require_once $popups_db;
            Popups_Database::create_tables();
        }
    }
}
