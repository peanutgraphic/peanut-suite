<?php
/**
 * Admin Handler
 *
 * Manages admin menu, scripts, and React app mounting.
 */

if (!defined('ABSPATH')) {
    exit;
}

class Peanut_Admin {

    private string $page_hook = '';

    /**
     * Add admin menu
     */
    public function add_admin_menu(): void {
        $this->page_hook = add_menu_page(
            __('Peanut Suite', 'peanut-suite'),
            __('Peanut Suite', 'peanut-suite'),
            'manage_options',
            'peanut-suite',
            [$this, 'render_admin_page'],
            $this->get_menu_icon(),
            30
        );

        // Submenus are handled by React Router
        // But we add them for WordPress admin visibility
        add_submenu_page(
            'peanut-suite',
            __('Dashboard', 'peanut-suite'),
            __('Dashboard', 'peanut-suite'),
            'manage_options',
            'peanut-suite',
            [$this, 'render_admin_page']
        );

        add_submenu_page(
            'peanut-suite',
            __('Campaigns', 'peanut-suite'),
            __('Campaigns', 'peanut-suite'),
            'manage_options',
            'peanut-suite#/campaigns',
            [$this, 'render_admin_page']
        );

        add_submenu_page(
            'peanut-suite',
            __('Links', 'peanut-suite'),
            __('Links', 'peanut-suite'),
            'manage_options',
            'peanut-suite#/links',
            [$this, 'render_admin_page']
        );

        add_submenu_page(
            'peanut-suite',
            __('Contacts', 'peanut-suite'),
            __('Contacts', 'peanut-suite'),
            'manage_options',
            'peanut-suite#/contacts',
            [$this, 'render_admin_page']
        );

        add_submenu_page(
            'peanut-suite',
            __('Settings', 'peanut-suite'),
            __('Settings', 'peanut-suite'),
            'manage_options',
            'peanut-suite#/settings',
            [$this, 'render_admin_page']
        );
    }

    /**
     * Render admin page (React mount point)
     */
    public function render_admin_page(): void {
        // Check for activation notice
        if (get_transient('peanut_activated')) {
            delete_transient('peanut_activated');
            echo '<div class="notice notice-success is-dismissible"><p>';
            echo esc_html__('Peanut Suite activated successfully!', 'peanut-suite');
            echo '</p></div>';
        }

        echo '<div id="peanut-app" class="peanut-admin-wrap"></div>';
    }

    /**
     * Enqueue admin scripts
     */
    public function enqueue_scripts(string $hook): void {
        if (!$this->is_plugin_page($hook)) {
            return;
        }

        // Read Vite manifest to get hashed filenames
        $manifest_path = PEANUT_PLUGIN_DIR . 'assets/dist/.vite/manifest.json';
        $js_file = 'js/main.js'; // Default fallback

        if (file_exists($manifest_path)) {
            $manifest = json_decode(file_get_contents($manifest_path), true);
            if (isset($manifest['src/main.tsx']['file'])) {
                $js_file = $manifest['src/main.tsx']['file'];
            }
        }

        // Main React app - use type="module" for Vite builds
        wp_enqueue_script(
            'peanut-admin',
            PEANUT_PLUGIN_URL . 'assets/dist/' . $js_file,
            [],
            PEANUT_VERSION,
            true
        );

        // Add module type for ES modules
        add_filter('script_loader_tag', function($tag, $handle) {
            if ($handle === 'peanut-admin') {
                return str_replace(' src', ' type="module" src', $tag);
            }
            return $tag;
        }, 10, 2);

        // Localize script data
        wp_localize_script('peanut-admin', 'peanutData', $this->get_script_data());
    }

    /**
     * Enqueue admin styles
     */
    public function enqueue_styles(string $hook): void {
        if (!$this->is_plugin_page($hook)) {
            return;
        }

        // Read Vite manifest to get CSS filename
        $manifest_path = PEANUT_PLUGIN_DIR . 'assets/dist/.vite/manifest.json';
        $css_file = 'css/main.css'; // Default fallback

        if (file_exists($manifest_path)) {
            $manifest = json_decode(file_get_contents($manifest_path), true);
            if (isset($manifest['src/main.tsx']['css'][0])) {
                $css_file = $manifest['src/main.tsx']['css'][0];
            }
        }

        wp_enqueue_style(
            'peanut-admin',
            PEANUT_PLUGIN_URL . 'assets/dist/' . $css_file,
            [],
            PEANUT_VERSION
        );

        // Hide WP admin notices on our page
        echo '<style>
            .peanut-admin-wrap .notice:not(.peanut-notice) { display: none !important; }
            #wpcontent { padding-left: 0 !important; }
            #wpbody-content { padding-bottom: 0 !important; }
            .peanut-admin-wrap { margin: 0; }
        </style>';
    }

    /**
     * Check if current page is plugin page
     */
    private function is_plugin_page(string $hook): bool {
        return str_contains($hook, 'peanut-suite');
    }

    /**
     * Get data for JavaScript
     */
    private function get_script_data(): array {
        $license = new Peanut_License();
        $license_data = $license->get_license_data();

        return [
            'apiUrl' => rest_url(PEANUT_API_NAMESPACE),
            'nonce' => wp_create_nonce('wp_rest'),
            'adminUrl' => admin_url(),
            'pluginUrl' => PEANUT_PLUGIN_URL,
            'version' => PEANUT_VERSION,
            'license' => [
                'status' => $license_data['status'],
                'tier' => $license_data['tier'],
                'isPro' => peanut_is_pro(),
            ],
            'modules' => $this->get_modules_data(),
            'user' => [
                'id' => get_current_user_id(),
                'name' => wp_get_current_user()->display_name,
                'email' => wp_get_current_user()->user_email,
            ],
            'settings' => get_option('peanut_settings', []),
            'i18n' => $this->get_i18n_strings(),
        ];
    }

    /**
     * Get modules data for frontend
     */
    private function get_modules_data(): array {
        $active = peanut_get_active_modules();

        return [
            'active' => $active,
            'available' => [
                'utm' => ['name' => 'UTM Builder', 'icon' => 'tag', 'tier' => 'free'],
                'links' => ['name' => 'Links', 'icon' => 'link', 'tier' => 'free'],
                'contacts' => ['name' => 'Contacts', 'icon' => 'users', 'tier' => 'free'],
                'dashboard' => ['name' => 'Dashboard', 'icon' => 'layout-dashboard', 'tier' => 'free'],
                'popups' => ['name' => 'Popups', 'icon' => 'message-square', 'tier' => 'pro'],
                'monitor' => ['name' => 'Monitor', 'icon' => 'activity', 'tier' => 'agency'],
            ],
        ];
    }

    /**
     * Get i18n strings for frontend
     */
    private function get_i18n_strings(): array {
        return [
            'save' => __('Save', 'peanut-suite'),
            'cancel' => __('Cancel', 'peanut-suite'),
            'delete' => __('Delete', 'peanut-suite'),
            'edit' => __('Edit', 'peanut-suite'),
            'create' => __('Create', 'peanut-suite'),
            'search' => __('Search...', 'peanut-suite'),
            'loading' => __('Loading...', 'peanut-suite'),
            'noResults' => __('No results found', 'peanut-suite'),
            'confirmDelete' => __('Are you sure you want to delete this?', 'peanut-suite'),
            'copied' => __('Copied to clipboard!', 'peanut-suite'),
            'upgrade' => __('Upgrade to Pro', 'peanut-suite'),
        ];
    }

    /**
     * Get menu icon (SVG)
     */
    private function get_menu_icon(): string {
        // Peanut icon as base64 SVG
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M8 12a4 4 0 0 1 8 0"/><circle cx="9" cy="9" r="1"/><circle cx="15" cy="9" r="1"/></svg>';

        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }
}
